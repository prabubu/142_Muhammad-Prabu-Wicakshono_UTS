# PROGRAM PENGUJIAN (TESTING)

setpoint = 50

def hitung_error(setpoint, output):
    return abs(setpoint - output)

def status_error(error):
    if error <= 2:
        return "STABIL"
    elif error <= 5:
        return "WARNING"
    else:
        return "TIDAK STABIL"

# 8 kasus pengujian
data_testing = [
    (49, "STABIL"),        # Error 1
    (48, "STABIL"),        # Error 2
    (47, "WARNING"),       # Error 3
    (46, "WARNING"),       # Error 4
    (45, "WARNING"),       # Error 5
    (44, "TIDAK STABIL"),  # Error 6
    (52, "STABIL"),        # Data realistis
    (60, "TIDAK STABIL")  # Data realistis
]

print("===== HASIL PENGUJIAN =====")

for nomor, (output, harapan) in enumerate(data_testing, start=1):
    error = hitung_error(setpoint, output)
    hasil = status_error(error)

    if hasil == harapan:
        status = "PASS"
    else:
        status = "FAIL"

    print(f"Test {nomor}: Output={output}, Error={error}, "
          f"Harapan={harapan}, Hasil={hasil}, {status}")